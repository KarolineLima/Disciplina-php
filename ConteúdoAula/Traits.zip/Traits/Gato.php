<?php

class Gato{
    private $raca;
    use Nomeado;
    use Pelagem;
}
?>