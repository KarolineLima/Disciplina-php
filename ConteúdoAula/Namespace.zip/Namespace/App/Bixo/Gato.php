<?php
namespace App\Bixo;
class Gato{
    private $raca;
    use \App\Caracteristicas\Nomeado;
    use \App\Caracteristicas\Pelagem;
}
?>